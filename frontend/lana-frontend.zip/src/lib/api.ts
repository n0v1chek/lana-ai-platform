import axios, { AxiosError, AxiosInstance } from 'axios';
import type {
  User,
  AuthResponse,
  LoginRequest,
  RegisterRequest,
  SendMessageRequest,
  ChatResponse,
  Conversation,
  SubscriptionPlan,
  Payment,
  ApiError,
} from '@/types';

// API URL - в продакшене заменить на реальный
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'https://lanaaihelper.ru/api';

// Создаём инстанс axios
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 30 секунд для AI ответов
});

// Интерсептор для добавления токена
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Интерсептор для обработки ошибок
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError<ApiError>) => {
    if (error.response?.status === 401) {
      // Токен истёк - разлогиниваем
      if (typeof window !== 'undefined') {
        localStorage.removeItem('token');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// ========== AUTH API ==========

export const authApi = {
  // Регистрация
  register: async (data: RegisterRequest): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>('/auth/register', data);
    return response.data;
  },

  // Вход
  login: async (data: LoginRequest): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>('/auth/login/json', data);
    return response.data;
  },

  // Получить текущего пользователя
  me: async (): Promise<User> => {
    const response = await api.get<User>('/auth/me');
    return response.data;
  },

  // Обновить профиль
  updateProfile: async (data: Partial<User>): Promise<User> => {
    const response = await api.patch<User>('/auth/me', data);
    return response.data;
  },

  // Сменить пароль
  changePassword: async (oldPassword: string, newPassword: string): Promise<void> => {
    await api.post('/auth/change-password', {
      old_password: oldPassword,
      new_password: newPassword,
    });
  },
};

// ========== CHAT API ==========

export const chatApi = {
  // Отправить сообщение
  send: async (data: SendMessageRequest): Promise<ChatResponse> => {
    const response = await api.post<ChatResponse>('/chat/send', data);
    return response.data;
  },

  // Получить все диалоги
  getConversations: async (): Promise<Conversation[]> => {
    const response = await api.get<Conversation[]>('/chat/conversations');
    return response.data;
  },

  // Получить диалог по ID
  getConversation: async (id: number): Promise<Conversation> => {
    const response = await api.get<Conversation>(`/chat/conversations/${id}`);
    return response.data;
  },

  // Удалить диалог
  deleteConversation: async (id: number): Promise<void> => {
    await api.delete(`/chat/conversations/${id}`);
  },
};

// ========== SUBSCRIPTIONS API ==========

export const subscriptionsApi = {
  // Получить все планы
  getPlans: async (): Promise<SubscriptionPlan[]> => {
    const response = await api.get<SubscriptionPlan[]>('/subscriptions/plans');
    return response.data;
  },

  // Получить мою подписку
  getMySubscription: async (): Promise<{ plan: SubscriptionPlan; user: User }> => {
    const response = await api.get('/subscriptions/my-subscription');
    return response.data;
  },

  // Апгрейд подписки
  upgrade: async (planType: string): Promise<{ payment_url: string }> => {
    const response = await api.post('/subscriptions/upgrade', { plan_type: planType });
    return response.data;
  },
};

// ========== PAYMENTS API ==========

export const paymentsApi = {
  // Создать платёж
  create: async (amount: number, planType: string): Promise<{ payment_url: string; payment_id: string }> => {
    const response = await api.post('/payments/create', { amount, plan_type: planType });
    return response.data;
  },

  // История платежей
  getHistory: async (): Promise<Payment[]> => {
    const response = await api.get<Payment[]>('/payments/history');
    return response.data;
  },
};

export default api;

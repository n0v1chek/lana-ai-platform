// Пользователь
export interface User {
  id: number;
  username: string;
  email: string | null;
  subscription_type: SubscriptionType;
  tokens_remaining: number;
  messages_today: number;
  daily_messages_limit: number;
  created_at: string;
}

// Типы подписок
export type SubscriptionType = 'FREE' | 'STARTER' | 'PRO' | 'BUSINESS';

// План подписки
export interface SubscriptionPlan {
  type: SubscriptionType;
  name: string;
  price: number;
  tokens: number;
  tokens_monthly: number;
  messages_per_day: number;
  daily_messages_limit: number;
  models: string[];
  features: string[];
}

// AI Модели
export type AIModel = 'gpt-4o-mini' | 'gpt-4o' | 'claude-sonnet-4' | 'gemini-pro';

export interface AIModelInfo {
  id: AIModel;
  name: string;
  description: string;
  icon: string;
  available: boolean;
}

// Сообщение в чате
export interface Message {
  id: number;
  role: 'user' | 'assistant';
  content: string;
  model?: AIModel;
  tokens_used?: number;
  created_at: string;
}

// Диалог
export interface Conversation {
  id: number;
  title: string;
  model: AIModel;
  messages: Message[];
  messages_count?: number;
  created_at: string;
  updated_at: string;
}

// Запрос на отправку сообщения
export interface SendMessageRequest {
  message: string;
  model: AIModel;
  conversation_id?: number;
}

// Ответ от AI
export interface ChatResponse {
  response: string;
  conversation_id: number;
  tokens_used: number;
  tokens_remaining: number;
}

// Авторизация
export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email?: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

// Платежи
export interface Payment {
  id: number;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  subscription_type: SubscriptionType;
  created_at: string;
}

// API Error
export interface ApiError {
  detail: string;
  status_code?: number;
}

// Состояние загрузки
export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

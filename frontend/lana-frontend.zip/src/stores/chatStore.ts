import { create } from 'zustand';
import type { Message, Conversation, AIModel } from '@/types';
import { chatApi } from '@/lib/api';

interface ChatState {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  messages: Message[];
  selectedModel: AIModel;
  isLoading: boolean;
  isSending: boolean;
  error: string | null;

  // Actions
  setSelectedModel: (model: AIModel) => void;
  sendMessage: (content: string) => Promise<void>;
  loadConversations: () => Promise<void>;
  loadConversation: (id: number) => Promise<void>;
  newConversation: () => void;
  deleteConversation: (id: number) => Promise<void>;
  clearError: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversations: [],
  currentConversation: null,
  messages: [],
  selectedModel: 'gpt-4o-mini',
  isLoading: false,
  isSending: false,
  error: null,

  setSelectedModel: (model: AIModel) => {
    set({ selectedModel: model });
  },

  sendMessage: async (content: string) => {
    const { selectedModel, currentConversation, messages } = get();

    // Add user message immediately
    const userMessage: Message = {
      id: Date.now(),
      role: 'user',
      content,
      created_at: new Date().toISOString(),
    };

    set({
      messages: [...messages, userMessage],
      isSending: true,
      error: null,
    });

    try {
      const response = await chatApi.send({
        message: content,
        model: selectedModel,
        conversation_id: currentConversation?.id,
      });

      // Add assistant message
      const assistantMessage: Message = {
        id: Date.now() + 1,
        role: 'assistant',
        content: response.response,
        model: selectedModel,
        tokens_used: response.tokens_used,
        created_at: new Date().toISOString(),
      };

      set((state) => ({
        messages: [...state.messages, assistantMessage],
        currentConversation: state.currentConversation
          ? { ...state.currentConversation, id: response.conversation_id }
          : {
              id: response.conversation_id,
              title: content.slice(0, 50),
              model: selectedModel,
              messages: [],
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            },
        isSending: false,
      }));
    } catch (error: unknown) {
      const axiosError = error as { response?: { data?: { detail?: string } } };
      set({
        error: axiosError.response?.data?.detail || 'Ошибка отправки сообщения',
        isSending: false,
      });
    }
  },

  loadConversations: async () => {
    set({ isLoading: true, error: null });
    try {
      const conversations = await chatApi.getConversations();
      set({ conversations, isLoading: false });
    } catch (error: unknown) {
      const axiosError = error as { response?: { data?: { detail?: string } } };
      set({
        error: axiosError.response?.data?.detail || 'Ошибка загрузки диалогов',
        isLoading: false,
      });
    }
  },

  loadConversation: async (id: number) => {
    set({ isLoading: true, error: null });
    try {
      const conversation = await chatApi.getConversation(id);
      set({
        currentConversation: conversation,
        messages: conversation.messages,
        selectedModel: conversation.model,
        isLoading: false,
      });
    } catch (error: unknown) {
      const axiosError = error as { response?: { data?: { detail?: string } } };
      set({
        error: axiosError.response?.data?.detail || 'Ошибка загрузки диалога',
        isLoading: false,
      });
    }
  },

  newConversation: () => {
    set({
      currentConversation: null,
      messages: [],
      error: null,
    });
  },

  deleteConversation: async (id: number) => {
    try {
      await chatApi.deleteConversation(id);
      set((state) => ({
        conversations: state.conversations.filter((c) => c.id !== id),
        currentConversation:
          state.currentConversation?.id === id ? null : state.currentConversation,
        messages: state.currentConversation?.id === id ? [] : state.messages,
      }));
    } catch (error: unknown) {
      const axiosError = error as { response?: { data?: { detail?: string } } };
      set({
        error: axiosError.response?.data?.detail || 'Ошибка удаления диалога',
      });
    }
  },

  clearError: () => set({ error: null }),
}));

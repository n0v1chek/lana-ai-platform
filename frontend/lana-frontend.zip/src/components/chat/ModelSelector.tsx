'use client';

import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Zap, Brain, Bot, Globe, Check } from 'lucide-react';
import type { AIModel } from '@/types';

const models: { id: AIModel; name: string; desc: string; icon: typeof Zap }[] = [
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini', desc: 'Быстрый и экономичный', icon: Zap },
  { id: 'gpt-4o', name: 'GPT-4o', desc: 'Самый умный', icon: Brain },
  { id: 'claude-sonnet-4', name: 'Claude Sonnet', desc: 'Творческий', icon: Bot },
  { id: 'gemini-pro', name: 'Gemini Pro', desc: 'Мультимодальный', icon: Globe },
];

interface ModelSelectorProps {
  value: AIModel;
  onChange: (model: AIModel) => void;
  disabled?: boolean;
}

export default function ModelSelector({ value, onChange, disabled }: ModelSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const selected = models.find((m) => m.id === value) || models[0];

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={`flex items-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-lana-300 dark:hover:border-lana-700 transition-colors ${
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        }`}
      >
        <selected.icon size={16} className="text-lana-500" />
        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
          {selected.name}
        </span>
        <ChevronDown
          size={14}
          className={`text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-slide-down">
          {models.map((model) => (
            <button
              key={model.id}
              onClick={() => {
                onChange(model.id);
                setIsOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
            >
              <model.icon size={18} className="text-lana-500" />
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-slate-900 dark:text-white">
                  {model.name}
                </p>
                <p className="text-xs text-slate-500">{model.desc}</p>
              </div>
              {model.id === value && (
                <Check size={16} className="text-lana-500" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

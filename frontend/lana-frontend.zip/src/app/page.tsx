'use client';

import Link from 'next/link';
import { 
  Sparkles, 
  Zap, 
  Shield, 
  MessageSquare, 
  ArrowRight, 
  Check,
  Bot,
  Brain,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
              Lana AI
            </span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors">
              Возможности
            </a>
            <a href="#pricing" className="text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors">
              Тарифы
            </a>
          </nav>

          <div className="flex items-center gap-3">
            <Link href="/login">
              <Button variant="ghost" size="sm">Войти</Button>
            </Link>
            <Link href="/register">
              <Button size="sm">Начать бесплатно</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-lana-100 dark:bg-lana-900/30 text-lana-700 dark:text-lana-300 text-sm font-medium mb-8">
            <Zap className="w-4 h-4" />
            Работает в России без VPN
          </div>

          {/* Title */}
          <h1 className="font-display text-5xl md:text-7xl font-bold text-slate-900 dark:text-white mb-6">
            AI-помощник
            <br />
            <span className="text-gradient">в одно касание</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-10">
            Доступ к лучшим нейросетям мира: GPT-4o, Claude, Gemini.
            Просто спроси — получи умный ответ.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button size="lg" rightIcon={<ArrowRight className="w-5 h-5" />}>
                Попробовать бесплатно
              </Button>
            </Link>
            <a href="#features">
              <Button variant="secondary" size="lg">
                Узнать больше
              </Button>
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto mt-16">
            <div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">4+</div>
              <div className="text-sm text-slate-500">AI моделей</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">0₽</div>
              <div className="text-sm text-slate-500">для старта</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-slate-900 dark:text-white">24/7</div>
              <div className="text-sm text-slate-500">доступность</div>
            </div>
          </div>
        </div>
      </section>

      {/* Models Section */}
      <section className="py-20 px-6 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
            Лучшие AI модели в одном месте
          </h2>
          <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
            Выбирай нужную модель под свою задачу — от быстрых ответов до глубокого анализа
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: 'GPT-4o Mini', desc: 'Быстрый и экономичный', icon: Zap, color: 'from-green-500 to-emerald-500' },
              { name: 'GPT-4o', desc: 'Самый умный от OpenAI', icon: Brain, color: 'from-blue-500 to-cyan-500' },
              { name: 'Claude Sonnet', desc: 'Творческий помощник', icon: Bot, color: 'from-orange-500 to-amber-500' },
              { name: 'Gemini Pro', desc: 'Мультимодальный AI', icon: Globe, color: 'from-purple-500 to-pink-500' },
            ].map((model) => (
              <div 
                key={model.name}
                className="group relative bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${model.color} flex items-center justify-center mb-4`}>
                  <model.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white mb-1">
                  {model.name}
                </h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                  {model.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
            Почему выбирают Lana AI
          </h2>
          <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
            Мы создали сервис, который ставит вашу приватность и удобство на первое место
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: 'Приватность',
                desc: 'Регистрация только по никнейму. Мы не собираем персональные данные и не читаем ваши диалоги.',
              },
              {
                icon: Zap,
                title: 'Скорость',
                desc: 'Мгновенные ответы от лучших AI моделей. Работает быстро даже на мобильном интернете.',
              },
              {
                icon: MessageSquare,
                title: 'Простота',
                desc: 'Никаких сложных настроек. Просто задай вопрос и получи умный ответ.',
              },
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <div className="w-14 h-14 rounded-2xl bg-lana-100 dark:bg-lana-900/30 flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-7 h-7 text-lana-600 dark:text-lana-400" />
                </div>
                <h3 className="font-display text-xl font-semibold text-slate-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-400">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
            Простые и честные тарифы
          </h2>
          <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
            Начните бесплатно, обновите когда будете готовы
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                name: 'FREE',
                price: '0',
                tokens: '30,000 токенов',
                features: ['10 сообщений/день', 'gpt-4o-mini', 'gemini-pro'],
                popular: false,
              },
              {
                name: 'STARTER',
                price: '1,490',
                tokens: '1,000,000 токенов',
                features: ['100 сообщений/день', 'Все модели', 'История чатов'],
                popular: false,
              },
              {
                name: 'PRO',
                price: '3,990',
                tokens: '5,000,000 токенов',
                features: ['500 сообщений/день', 'Все модели', 'API доступ', 'Приоритет'],
                popular: true,
              },
              {
                name: 'BUSINESS',
                price: '12,990',
                tokens: '20,000,000 токенов',
                features: ['Без лимитов', 'Мультиюзер (10 чел)', 'SLA поддержка', 'API доступ'],
                popular: false,
              },
            ].map((plan) => (
              <div
                key={plan.name}
                className={`relative bg-white dark:bg-slate-800 rounded-2xl p-6 ${
                  plan.popular ? 'ring-2 ring-lana-500 shadow-xl' : 'shadow-sm'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-lana-500 text-white text-xs font-medium rounded-full">
                    Популярный
                  </div>
                )}
                <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white mb-2">
                  {plan.name}
                </h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-slate-900 dark:text-white">{plan.price}₽</span>
                  <span className="text-slate-500">/мес</span>
                </div>
                <p className="text-sm text-lana-600 dark:text-lana-400 mb-4">{plan.tokens}</p>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link href="/register">
                  <Button variant={plan.popular ? 'primary' : 'secondary'} className="w-full">
                    {plan.price === '0' ? 'Начать бесплатно' : 'Выбрать'}
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-lana-500 to-purple-500 rounded-3xl p-12 relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-4">
                Готовы попробовать?
              </h2>
              <p className="text-white/80 text-lg mb-8 max-w-xl mx-auto">
                Присоединяйтесь к пользователям, которые уже используют Lana AI для работы и творчества
              </p>
              <Link href="/register">
                <Button
                  size="lg"
                  className="bg-white text-lana-600 hover:bg-slate-100"
                  rightIcon={<ArrowRight className="w-5 h-5" />}
                >
                  Создать аккаунт бесплатно
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-lg text-slate-900 dark:text-white">
                Lana AI Helper
              </span>
            </div>
            
            <nav className="flex flex-wrap justify-center gap-6 text-sm text-slate-600 dark:text-slate-400">
              <Link href="/privacy" className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Политика конфиденциальности
              </Link>
              <Link href="/terms" className="hover:text-slate-900 dark:hover:text-white transition-colors">
                Условия использования
              </Link>
            </nav>

            <p className="text-sm text-slate-500">
              © 2025 Lana AI Helper
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

'use client';

import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Sparkles,
  Plus,
  MessageSquare,
  Settings,
  LogOut,
  CreditCard,
  History,
  Menu,
  X,
  Coins,
} from 'lucide-react';
import { useState } from 'react';
import { useAuthStore } from '@/stores/authStore';
import { useChatStore } from '@/stores/chatStore';
import { ChatMessage, ChatInput, ModelSelector } from '@/components/chat';
import { Button } from '@/components/ui';

export default function ChatPage() {
  const router = useRouter();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const { user, isAuthenticated, isLoading: authLoading, fetchUser, logout } = useAuthStore();
  const {
    messages,
    conversations,
    selectedModel,
    isSending,
    setSelectedModel,
    sendMessage,
    loadConversations,
    newConversation,
  } = useChatStore();

  // Check auth on mount
  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [authLoading, isAuthenticated, router]);

  // Load conversations
  useEffect(() => {
    if (isAuthenticated) {
      loadConversations();
    }
  }, [isAuthenticated, loadConversations]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <p className="text-slate-500">Загрузка...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-slate-50 dark:bg-slate-900">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 transform transition-transform duration-300 lg:relative lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <div className="flex items-center justify-between">
              <Link href="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="font-display font-bold text-lg text-slate-900 dark:text-white">
                  Lana AI
                </span>
              </Link>
              <button
                onClick={() => setSidebarOpen(false)}
                className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* New Chat Button */}
          <div className="p-4">
            <Button
              onClick={newConversation}
              className="w-full"
              leftIcon={<Plus size={18} />}
            >
              Новый чат
            </Button>
          </div>

          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto px-2">
            <p className="px-2 py-2 text-xs font-medium text-slate-400 uppercase tracking-wider">
              История
            </p>
            {conversations.length === 0 ? (
              <p className="text-center text-sm text-slate-400 py-8">
                Нет диалогов
              </p>
            ) : (
              <div className="space-y-1">
                {conversations.slice(0, 20).map((conv) => (
                  <button
                    key={conv.id}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-left transition-colors"
                  >
                    <MessageSquare size={16} className="text-slate-400 flex-shrink-0" />
                    <span className="text-sm text-slate-700 dark:text-slate-300 truncate">
                      {conv.title || 'Без названия'}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* User Info & Menu */}
          <div className="p-4 border-t border-slate-200 dark:border-slate-700">
            {/* Tokens */}
            <div className="flex items-center justify-between mb-4 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
              <div className="flex items-center gap-2">
                <Coins size={16} className="text-amber-500" />
                <span className="text-sm text-slate-600 dark:text-slate-300">Токены</span>
              </div>
              <span className="text-sm font-semibold text-slate-900 dark:text-white">
                {user?.tokens_remaining?.toLocaleString() || 0}
              </span>
            </div>

            {/* Menu */}
            <div className="space-y-1">
              <Link
                href="/history"
                className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <History size={18} className="text-slate-400" />
                <span className="text-sm text-slate-700 dark:text-slate-300">История</span>
              </Link>
              <Link
                href="/pricing"
                className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <CreditCard size={18} className="text-slate-400" />
                <span className="text-sm text-slate-700 dark:text-slate-300">Тарифы</span>
              </Link>
              <Link
                href="/settings"
                className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <Settings size={18} className="text-slate-400" />
                <span className="text-sm text-slate-700 dark:text-slate-300">Настройки</span>
              </Link>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 dark:text-red-400 transition-colors"
              >
                <LogOut size={18} />
                <span className="text-sm">Выйти</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-4 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <Menu size={20} />
            </button>
            <ModelSelector
              value={selectedModel}
              onChange={setSelectedModel}
              disabled={isSending}
            />
          </div>

          <div className="flex items-center gap-2 text-sm">
            <span className="text-slate-500">Привет,</span>
            <span className="font-medium text-slate-900 dark:text-white">
              {user?.username || 'Пользователь'}
            </span>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            // Empty state
            <div className="h-full flex items-center justify-center p-8">
              <div className="text-center max-w-md">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white mb-2">
                  Чем могу помочь?
                </h2>
                <p className="text-slate-500 dark:text-slate-400 mb-8">
                  Задайте любой вопрос — я постараюсь дать полезный ответ
                </p>
                <div className="grid gap-2">
                  {[
                    'Объясни квантовые вычисления простыми словами',
                    'Напиши код на Python для сортировки списка',
                    'Придумай идею для мобильного приложения',
                  ].map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(prompt)}
                      className="text-left px-4 py-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-lana-300 dark:hover:border-lana-600 transition-colors text-sm text-slate-600 dark:text-slate-400"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            // Messages list
            <div className="max-w-4xl mx-auto p-4 space-y-6">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              {isSending && (
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center animate-pulse">
                    <Sparkles size={16} className="text-white" />
                  </div>
                  <div className="bg-white dark:bg-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input */}
        <ChatInput onSend={sendMessage} isLoading={isSending} />
      </main>
    </div>
  );
}

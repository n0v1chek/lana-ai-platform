'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Sparkles,
  ArrowLeft,
  Check,
  Crown,
  Zap,
  Star,
  Building,
  Coins,
  TrendingUp,
} from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { subscriptionsApi } from '@/lib/api';
import { Button, Card } from '@/components/ui';
import type { SubscriptionPlan } from '@/types';

const planIcons: Record<string, React.ElementType> = {
  FREE: Zap,
  STARTER: Star,
  PRO: Crown,
  BUSINESS: Building,
};

const planColors: Record<string, string> = {
  FREE: 'from-slate-500 to-slate-600',
  STARTER: 'from-blue-500 to-cyan-500',
  PRO: 'from-lana-500 to-purple-500',
  BUSINESS: 'from-amber-500 to-orange-500',
};

export default function PricingPage() {
  const router = useRouter();
  const { user, isAuthenticated, isLoading: authLoading, fetchUser } = useAuthStore();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState<string | null>(null);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [authLoading, isAuthenticated, router]);

  useEffect(() => {
    if (isAuthenticated) {
      loadPlans();
    }
  }, [isAuthenticated]);

  const loadPlans = async () => {
    try {
      setLoading(true);
      const data = await subscriptionsApi.getPlans();
      setPlans(data);
    } catch (error) {
      console.error('Failed to load plans:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = async (planType: string) => {
    try {
      setUpgrading(planType);
      const response = await subscriptionsApi.upgrade(planType);
      if (response.payment_url) {
        window.location.href = response.payment_url;
      }
    } catch (error) {
      console.error('Failed to upgrade:', error);
      alert('Не удалось создать платёж. Попробуйте позже.');
    } finally {
      setUpgrading(null);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ru-RU').format(price);
  };

  const formatTokens = (tokens: number) => {
    if (tokens >= 1_000_000) {
      return `${tokens / 1_000_000}M`;
    }
    if (tokens >= 1_000) {
      return `${tokens / 1_000}K`;
    }
    return tokens.toString();
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-lana-500 to-purple-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <p className="text-slate-500">Загрузка...</p>
        </div>
      </div>
    );
  }

  const currentPlan = user?.subscription_type || 'FREE';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/chat">
              <Button variant="ghost" size="sm" leftIcon={<ArrowLeft size={18} />}>
                Назад
              </Button>
            </Link>
            <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Тарифы
            </h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Current Plan Banner */}
        <Card className="mb-8 bg-gradient-to-r from-lana-500 to-purple-500 text-white" padding="lg">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                <Coins className="w-6 h-6" />
              </div>
              <div>
                <p className="text-white/80 text-sm">Ваш текущий план</p>
                <p className="font-display text-2xl font-bold">{currentPlan}</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <p className="text-white/80 text-sm">Осталось токенов</p>
                <p className="font-display text-2xl font-bold">
                  {user?.tokens_remaining?.toLocaleString() || 0}
                </p>
              </div>
              <div className="text-center">
                <p className="text-white/80 text-sm">Лимит в день</p>
                <p className="font-display text-2xl font-bold">
                  {user?.daily_messages_limit || 10}
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Plans Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="w-8 h-8 border-2 border-lana-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-slate-500">Загрузка тарифов...</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan) => {
              const Icon = planIcons[plan.type] || Zap;
              const color = planColors[plan.type] || 'from-slate-500 to-slate-600';
              const isCurrent = plan.type === currentPlan;
              const isPopular = plan.type === 'PRO';

              return (
                <Card
                  key={plan.type}
                  className={`relative ${isPopular ? 'ring-2 ring-lana-500 shadow-xl' : ''} ${
                    isCurrent ? 'bg-lana-50 dark:bg-lana-900/20' : ''
                  }`}
                  padding="lg"
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-lana-500 text-white text-xs font-medium rounded-full">
                      Популярный
                    </div>
                  )}
                  
                  {isCurrent && (
                    <div className="absolute -top-3 right-4 px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                      Текущий
                    </div>
                  )}

                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>

                  <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mb-1">
                    {plan.name || plan.type}
                  </h3>

                  <div className="mb-4">
                    <span className="text-3xl font-bold text-slate-900 dark:text-white">
                      {formatPrice(plan.price)}₽
                    </span>
                    <span className="text-slate-500">/мес</span>
                  </div>

                  <div className="flex items-center gap-2 mb-4 text-lana-600 dark:text-lana-400">
                    <TrendingUp size={16} />
                    <span className="text-sm font-medium">
                      {formatTokens(plan.tokens_monthly)} токенов
                    </span>
                  </div>

                  <ul className="space-y-2 mb-6">
                    <li className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {plan.daily_messages_limit === -1 
                        ? 'Без лимита сообщений' 
                        : `${plan.daily_messages_limit} сообщений/день`}
                    </li>
                    {plan.type !== 'FREE' && (
                      <li className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        Все AI модели
                      </li>
                    )}
                    {(plan.type === 'PRO' || plan.type === 'BUSINESS') && (
                      <li className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        API доступ
                      </li>
                    )}
                    {plan.type === 'BUSINESS' && (
                      <>
                        <li className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                          <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                          Мультиюзер (10 чел)
                        </li>
                        <li className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                          <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                          SLA поддержка
                        </li>
                      </>
                    )}
                  </ul>

                  <Button
                    className="w-full"
                    variant={isCurrent ? 'secondary' : isPopular ? 'primary' : 'secondary'}
                    disabled={isCurrent || plan.price === 0}
                    isLoading={upgrading === plan.type}
                    onClick={() => handleUpgrade(plan.type)}
                  >
                    {isCurrent 
                      ? 'Текущий план' 
                      : plan.price === 0 
                        ? 'Бесплатно' 
                        : 'Выбрать'}
                  </Button>
                </Card>
              );
            })}
          </div>
        )}

        {/* FAQ Section */}
        <div className="mt-12">
          <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white mb-6 text-center">
            Часто задаваемые вопросы
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card padding="md">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                Что такое токены?
              </h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Токены — это единица измерения текста для AI. В среднем 1000 токенов ≈ 750 слов. 
                Одно сообщение обычно использует 500-2000 токенов.
              </p>
            </Card>
            
            <Card padding="md">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                Можно ли отменить подписку?
              </h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Да, вы можете отменить подписку в любое время. Доступ сохранится до конца оплаченного периода.
              </p>
            </Card>
            
            <Card padding="md">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                Какие способы оплаты принимаются?
              </h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Мы принимаем банковские карты РФ, СБП и электронные кошельки через ЮKassa.
              </p>
            </Card>
            
            <Card padding="md">
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                Токены переносятся на следующий месяц?
              </h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                Неиспользованные токены не переносятся. Лимит обновляется с каждой новой подпиской.
              </p>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
